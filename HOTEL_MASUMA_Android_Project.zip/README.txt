HOTEL MASUMA & RESTAURANT — Android Studio Starter Project

This is a starter Android project source, not a compiled APK.
It includes basic menu entry, bill cart, discount, saved bill totals, daily/monthly report, and a first-pass Bluetooth SPP print attempt for paired printers.

Build:
1. Install Android Studio on a computer.
2. Open this extracted folder as an existing project.
3. Let Gradle sync and install the Android SDK platform required by compileSdk 35.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Test on your Android phone. Pair the printer in Android Settings > Bluetooth first.

Important:
- The HL450 product image indicates BT/USB, 57 mm paper, 48 mm print width. Bluetooth printing compatibility depends on the exact printer firmware/protocol; this project uses a common Bluetooth SPP UUID and ESC/POS-like commands and must be tested on the actual printer.
- This source has not been compiled or tested in this environment; it is not a guaranteed ready-to-install APK.
- The app stores data locally on each phone; it does not synchronize data between phones.
- Keep backup exports and test printing before using for real customer transactions.
- This starter is non-GST by design; check tax/legal requirements before official use.
