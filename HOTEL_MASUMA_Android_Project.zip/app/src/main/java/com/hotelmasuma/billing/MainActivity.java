package com.hotelmasuma.billing;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout base, body, menuList, cartList;
    EditText nameInput, priceInput, qtyInput, discountInput;
    TextView subtotalView, totalView, reportView;
    ArrayList<Item> menu = new ArrayList<>();
    ArrayList<CartItem> cart = new ArrayList<>();
    JSONArray bills = new JSONArray();
    BluetoothDevice printerDevice;
    final int REQ_BT = 44;
    double discount = 0;
    static class Item { String name; double price; Item(String n,double p){name=n;price=p;} }
    static class CartItem { String name; double price; int qty; CartItem(String n,double p,int q){name=n;price=p;qty=q;} double total(){return price*qty;} }

    @Override public void onCreate(Bundle b) { super.onCreate(b); loadData(); buildUi(); renderMenu(); renderCart(); renderReports(); }
    int dp(int x){return (int)(getResources().getDisplayMetrics().density*x);}
    TextView text(String s,int size, boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xff17221c);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(0,dp(5),0,dp(5));return t;}
    Button button(String s, Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());return b;}
    EditText edit(String hint, int type){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setInputType(type);return e;}
    void buildUi(){
        base=new LinearLayout(this);base.setOrientation(1);base.setBackgroundColor(0xfff4f6f3);
        TextView header=text("HOTEL MASUMA & RESTAURANT\nBILLING",20,true);header.setTextColor(-1);header.setBackgroundColor(0xff12372a);header.setPadding(dp(16),dp(18),dp(12),dp(18));base.addView(header);
        HorizontalScrollView hsv=new HorizontalScrollView(this);LinearLayout tabs=new LinearLayout(this);
        tabs.addView(button("New Bill",()->showBilling()));tabs.addView(button("Food Menu",()->showMenuEditor()));tabs.addView(button("Reports",()->showReports()));tabs.addView(button("Printer",()->choosePrinter()));hsv.addView(tabs);base.addView(hsv);
        ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);body.setPadding(dp(14),dp(10),dp(14),dp(24));scroll.addView(body);base.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(base);showBilling();
    }
    void showBilling(){
        body.removeAllViews();body.addView(text("Tap a food item to add it to the bill.",14,false));
        for(Item it:menu){body.addView(button(it.name+"  •  ₹"+fmt(it.price),()->{cart.add(new CartItem(it.name,it.price,1));renderCart();}));}
        body.addView(text("Current Bill",18,true));cartList=new LinearLayout(this);cartList.setOrientation(1);body.addView(cartList);
        discountInput=edit("Discount ₹",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);discountInput.setText("0");body.addView(discountInput);
        subtotalView=text("Subtotal: ₹0.00",16,true);totalView=text("TOTAL: ₹0.00",20,true);body.addView(subtotalView);body.addView(totalView);
        body.addView(button("Recalculate",()->renderCart()));
        body.addView(button("Save Bill",()->saveBill()));
        body.addView(button("Print Current Bill",()->printReceipt(false)));
        body.addView(button("Clear Bill",()->{cart.clear();renderCart();}));
    }
    void showMenuEditor(){
        body.removeAllViews();body.addView(text("Add a food item",18,true));
        nameInput=edit("Food name (e.g. Chicken Biryani)",InputType.TYPE_CLASS_TEXT);priceInput=edit("Price ₹",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        body.addView(nameInput);body.addView(priceInput);body.addView(button("Save Food Item",()->{String n=nameInput.getText().toString().trim();try{double p=Double.parseDouble(priceInput.getText().toString());if(n.isEmpty()||p<0)throw new Exception();menu.add(new Item(n,p));saveData();nameInput.setText("");priceInput.setText("");new AlertDialog.Builder(this).setMessage("Food item saved").setPositiveButton("OK",null).show();}catch(Exception e){Toast.makeText(this,"Enter food name and valid price",Toast.LENGTH_SHORT).show();}}));
        body.addView(text("Current Menu",18,true));
        for(int i=0;i<menu.size();i++){final int ix=i;body.addView(button(menu.get(i).name+" • ₹"+fmt(menu.get(i).price)+"  (tap to delete)",()->new AlertDialog.Builder(this).setMessage("Delete "+menu.get(ix).name+"?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{menu.remove(ix);saveData();showMenuEditor();}).show()));}
        body.addView(text("Menu is stored on this phone.",12,false));
    }
    void renderMenu(){ }
    void renderCart(){
        if(cartList==null)return;cartList.removeAllViews();double sub=0;
        for(int i=0;i<cart.size();i++){CartItem c=cart.get(i);sub+=c.total();final int ix=i;LinearLayout row=new LinearLayout(this);row.setOrientation(0);TextView label=text(c.name+" x"+c.qty+"\n₹"+fmt(c.total()),14,true);row.addView(label,new LinearLayout.LayoutParams(0,-2,1));row.addView(button("−",()->{if(c.qty>1)c.qty--;else cart.remove(ix);renderCart();}));row.addView(button("+",()->{c.qty++;renderCart();}));row.addView(button("×",()->{cart.remove(ix);renderCart();}));cartList.addView(row);}
        discount=0;try{if(discountInput!=null)discount=Math.max(0,Double.parseDouble(discountInput.getText().toString()));}catch(Exception ignored){}
        discount=Math.min(discount,sub);if(subtotalView!=null)subtotalView.setText("Subtotal: ₹"+fmt(sub));if(totalView!=null)totalView.setText("TOTAL: ₹"+fmt(sub-discount));
    }
    void saveBill(){
        if(cart.isEmpty()){toast("Add food items first");return;}
        JSONObject b=makeBill();if(b==null)return;bills.put(b);saveData();toast("Bill saved");cart.clear();renderCart();renderReports();
    }
    JSONObject makeBill(){
        try{JSONObject b=new JSONObject();b.put("id","HM"+System.currentTimeMillis());b.put("date",System.currentTimeMillis());JSONArray items=new JSONArray();double sub=0;for(CartItem c:cart){JSONObject x=new JSONObject();x.put("name",c.name);x.put("price",c.price);x.put("qty",c.qty);items.put(x);sub+=c.total();}double d=0;try{d=Double.parseDouble(discountInput.getText().toString());}catch(Exception ignored){}d=Math.max(0,Math.min(d,sub));b.put("items",items);b.put("subtotal",sub);b.put("discount",d);b.put("total",sub-d);return b;}catch(Exception e){return null;}
    }
    void printReceipt(boolean saved){
        if(cart.isEmpty()){toast("Add items before printing");return;}
        JSONObject b=makeBill();StringBuilder s=new StringBuilder();s.append(" HOTEL MASUMA & RESTAURANT\n");s.append("------------------------------\n");s.append("Bill: ").append(b.optString("id")).append("\n");s.append(new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date())).append("\n");s.append("------------------------------\n");
        JSONArray a=b.optJSONArray("items");for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);s.append(x.optString("name")).append("\n  ").append(x.optInt("qty")).append(" x ").append(fmt(x.optDouble("price"))).append(" = ").append(fmt(x.optInt("qty")*x.optDouble("price"))).append("\n");}
        s.append("------------------------------\nSubtotal: ₹").append(fmt(b.optDouble("subtotal"))).append("\nDiscount: ₹").append(fmt(b.optDouble("discount"))).append("\nTOTAL: ₹").append(fmt(b.optDouble("total"))).append("\n\nThank you! Visit again.\n\n\n");
        if(printerDevice==null){new AlertDialog.Builder(this).setTitle("Printer not selected").setMessage(s.toString()+"\nPair the HL450 in Android Bluetooth settings, then tap Printer. Direct printing support depends on printer firmware.").setPositiveButton("OK",null).show();return;}
        if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);return;}
        final String receipt=s.toString();new Thread(()->{try{BluetoothSocket sock=printerDevice.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));sock.connect();OutputStream out=sock.getOutputStream();out.write(new byte[]{0x1b,0x40});out.write(receipt.getBytes(Charset.forName("GBK")));out.write(new byte[]{0x0a,0x0a,0x0a,0x1d,0x56,0x00});out.flush();sock.close();runOnUiThread(()->toast("Print sent"));}catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setMessage("Printer connection failed: "+e.getMessage()+"\nConfirm the printer is paired and supports standard Bluetooth SPP.").setPositiveButton("OK",null).show());}}).start();
    }
    void choosePrinter(){
        if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);return;}
        try{BluetoothAdapter ad=BluetoothAdapter.getDefaultAdapter();if(ad==null){toast("This phone has no Bluetooth");return;}if(!ad.isEnabled()){startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),7);return;}
            Set<BluetoothDevice> devices=ad.getBondedDevices();ArrayList<BluetoothDevice> list=new ArrayList<>(devices);if(list.isEmpty()){new AlertDialog.Builder(this).setMessage("First pair the printer from Android Settings > Bluetooth.").setPositiveButton("OK",null).show();return;}
            String[] labels=new String[list.size()];for(int i=0;i<list.size();i++)labels[i]=list.get(i).getName()+"\n"+list.get(i).getAddress();new AlertDialog.Builder(this).setTitle("Select paired printer").setItems(labels,(d,which)->{printerDevice=list.get(which);toast("Selected "+printerDevice.getName());}).show();
        }catch(Exception e){toast("Bluetooth error: "+e.getMessage());}
    }
    void showReports(){
        body.removeAllViews();double day=0,month=0;int dc=0,mc=0;Calendar now=Calendar.getInstance();
        for(int i=0;i<bills.length();i++){JSONObject b=bills.optJSONObject(i);Calendar c=Calendar.getInstance();c.setTimeInMillis(b.optLong("date"));if(c.get(Calendar.YEAR)==now.get(Calendar.YEAR)&&c.get(Calendar.DAY_OF_YEAR)==now.get(Calendar.DAY_OF_YEAR)){day+=b.optDouble("total");dc++;}if(c.get(Calendar.YEAR)==now.get(Calendar.YEAR)&&c.get(Calendar.MONTH)==now.get(Calendar.MONTH)){month+=b.optDouble("total");mc++;}}
        body.addView(text("Today's Sales: ₹"+fmt(day)+" ("+dc+" bills)",18,true));body.addView(text("This Month: ₹"+fmt(month)+" ("+mc+" bills)",18,true));body.addView(button("Export / Share Sales JSON",()->shareData()));
        for(int i=bills.length()-1;i>=0;i--){JSONObject b=bills.optJSONObject(i);body.addView(text(b.optString("id")+" • ₹"+fmt(b.optDouble("total")),14,true));}
        body.addView(text("For safe keeping, regularly export your records.",12,false));
    }
    void renderReports(){ }
    void shareData(){try{Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_SUBJECT,"Hotel Masuma sales backup");send.putExtra(Intent.EXTRA_TEXT,loadRaw());startActivity(Intent.createChooser(send,"Save/share backup"));}catch(Exception e){toast("Unable to share backup");}}
    String loadRaw(){return getPreferences(0).getString("data","{}");}
    void loadData(){try{JSONObject root=new JSONObject(getPreferences(0).getString("data","{}"));JSONArray m=root.optJSONArray("menu");if(m!=null)for(int i=0;i<m.length();i++){JSONObject x=m.getJSONObject(i);menu.add(new Item(x.getString("name"),x.getDouble("price")));}bills=root.optJSONArray("bills");if(bills==null)bills=new JSONArray();}catch(Exception ignored){}}
    void saveData(){try{JSONObject root=new JSONObject();JSONArray m=new JSONArray();for(Item x:menu){JSONObject o=new JSONObject();o.put("name",x.name);o.put("price",x.price);m.put(o);}root.put("menu",m);root.put("bills",bills);getPreferences(0).edit().putString("data",root.toString()).apply();}catch(Exception ignored){}}
    String fmt(double n){return String.format(Locale.US,"%.2f",n);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_BT){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)choosePrinter();else toast("Bluetooth permission is required to connect printer");}}
}
